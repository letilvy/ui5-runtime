/*!
 * OpenUI5
 * (c) Copyright 2009-2019 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(['sap/ui/commons/library','sap/ui/layout/form/FormElement'],function(l,L){"use strict";var F=L.extend("sap.ui.commons.form.FormElement",{metadata:{deprecated:true,library:"sap.ui.commons"}});return F;});
