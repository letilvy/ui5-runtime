/*!
 * OpenUI5
 * (c) Copyright 2009-2019 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(["./_merge"],function(_){"use strict";var d=function(){var a=[true,true];a.push.apply(a,arguments);return _.apply(null,a);};return d;});
